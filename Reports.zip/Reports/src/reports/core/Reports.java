package reports.core;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import reports.connectors.Connector;
import reports.utils.files.FileText;
import reports.utils.files.I_File;
public class Reports {
    /**
     * Método que genera un file sobre una query SQL
     * @param file nombre del file en que se va a escribir el resultado.
     * @param query query SQL a ejecutar en la base.
     * @param headers true indica que se agrega encabezado de columnas. 
     */
    public static void generar(String file, String query, boolean headers){
        try (
                Connection conn=Connector.getConnection();
                ResultSet rs=conn.createStatement().executeQuery(query);
        ){
            I_File fText=new FileText(file);
            ResultSetMetaData rsmd=rs.getMetaData();
            if(headers) fText.addLine(getHeaders(rsmd));
            while(rs.next()){
                String record="";
                for(int a=1;a<=rsmd.getColumnCount();a++){
                    record+=rs.getObject(a)+",";
                }
                fText.addLine(record);
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }
    /**
     * Esta funcion crea los encabezados
     * rsdm metadatos
     * @return String con los headers.
     */
    public static String getHeaders(ResultSetMetaData rsmd){
        String headers="";
        try{
            for(int a=1;a<=rsmd.getColumnCount();a++){
                headers+=rsmd.getColumnName(a)+",";
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return headers;
    }
}