package reports.test;
import java.util.List;
import reports.utils.files.FileText;
import reports.utils.files.I_File;
public class TestFile {
    public static void main(String[] args) {
        //Testeo de utilidad de archivos 'FileText'
        String file="texto.txt";
        I_File fText=new FileText(file);
        fText.addLines(List.of("Lunes","Martes","Miércoles","Jueves","Viernes","Sábado","Domingo"));
        fText.getAll().forEach(System.out::println);
    }
}