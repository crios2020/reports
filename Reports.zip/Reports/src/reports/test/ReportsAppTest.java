package reports.test;

import reports.core.Reports;

public class ReportsAppTest {
    public static void main(String[] args) {
        //Testeo del Core de reporteria
        String file="result.txt";
        String query="select         sol_personales.id ID,\n" +
                        "	     cod_universidades.cod_ona_uni Cod_Inst,\n" +
                        "            cod_universidades.universidad Nombre_Inst,\n" +
                        "            cod_uas.cod_ona_ua Cod_Facultad,\n" +
                        "            cod_uas.Unidad_Academica Nombre_Facultad,\n" +
                        "            cod_carreras.cod_titulo Cod_Tit_Araucano,\n" +
                        "            cod_carreras.carrera Nombre_Tit_Araucano,\n" +
                        "            sol_personales.dni DNI,\n" +
                        "            sol_personales.apellido Apellido,\n" +
                        "			sol_personales.nombre Nombre,\n" +
                        "            sol_personales.nacionalidad Nacionalidad,\n" +
                        "            sol_personales.sexo Sexo,            \n" +
                        "			sol_personales.fn Fecha_Nac,\n" +
                        "            sol_personales.prioritario Prioritario,\n" +
                        "            sol_academico.anioing Año_Ingreso        \n" +
                        "from		sol_sistema\n" +
                        "inner join 	sol_personales\n" +
                        "on 			sol_sistema.id=sol_personales.id\n" +
                        "inner join	sol_academico\n" +
                        "on			sol_sistema.id=sol_academico.id\n" +
                        "inner join	cod_universidades\n" +
                        "on			sol_academico.universidad=cod_universidades.id_univ\n" +
                        "inner join	cod_uas\n" +
                        "on 			sol_academico.ua=cod_uas.id_UA\n" +
                        "inner join	cod_carreras\n" +
                        "on			sol_academico.carrera=cod_carreras.cod_carrera\n" +
                        "where		sol_personales.nacionalidad='Argentina'\n" +
                        "and 		sol_personales.fn < '2003-05-16'\n" +
                        ";";
        Reports.generar(file, query, true);
    }
}